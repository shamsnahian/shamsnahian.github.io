# Personal Site for Shams Nahian

This is a GitHub Pages-ready personal brand and resume site.

## Live URL
https://shamsnahian.github.io

## Contact
- LinkedIn: https://www.linkedin.com/in/shams-nahian
- Email: shamsnahian07@gmail.com

## How to Deploy
1. Create a repository named `shamsnahian.github.io`.
2. Upload all files from this ZIP to the repo root.
3. Enable GitHub Pages in Settings → Pages → Source: main branch, root folder.
4. Visit https://shamsnahian.github.io.
